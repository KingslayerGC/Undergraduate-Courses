function voice = q(pitch)
%  quaver
voice = note(pitch, 1/8);
end