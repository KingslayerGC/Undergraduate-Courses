function y = tone1(x)
a0 =      0.7629;
       a1 =     -0.0998;
       b1 =      -1.942;
       a2 =      -2.055;
       b2 =       0.025;
       a3 =     -0.4202;
       b3 =       1.838;
       a4 =       1.539;
       b4 =      0.5161;
       a5 =      0.5108;
       b5 =      -1.285;
       a6 =     -0.7253;
       b6 =       -0.58;
       a7 =     -0.4725;
       b7 =      0.3822;
       a8 =     0.06558;
       b8 =      0.3378;
       w =       1.675;

f = @(x) a0 + a1*cos(x*w) + b1*sin(x*w) + ...
        a2*cos(2*x*w) + b2*sin(2*x*w) + a3*cos(3*x*w) + b3*sin(3*x*w) + ...
        a4*cos(4*x*w) + b4*sin(4*x*w) + a5*cos(5*x*w) + b5*sin(5*x*w) + ...
        a6*cos(6*x*w) + b6*sin(6*x*w) + a7*cos(7*x*w) + b7*sin(7*x*w) + ...
        a8*cos(8*x*w) + b8*sin(8*x*w);
    
y = f(x);
end