function y = tone2(x)
a0 =       35.22;
       a1 =       23.11;
       b1 =       62.18;
       a2 =      -42.03;
       b2 =       36.22;
       a3 =      -35.61;
       b3 =      -19.49;
       a4 =       3.689;
       b4 =       -25.7;
       a5 =       13.49;
       b5 =      -3.162;
       a6 =       3.593;
       b6 =       4.901;
       a7 =      -0.845;
       b7 =       1.646;
       a8 =     -0.4106;
       b8 =     0.04506;
       w =       1.409;


f = @(x) a0 + a1*cos(x*w) + b1*sin(x*w) + ...
        a2*cos(2*x*w) + b2*sin(2*x*w) + a3*cos(3*x*w) + b3*sin(3*x*w) + ...
        a4*cos(4*x*w) + b4*sin(4*x*w) + a5*cos(5*x*w) + b5*sin(5*x*w) + ...
        a6*cos(6*x*w) + b6*sin(6*x*w) + a7*cos(7*x*w) + b7*sin(7*x*w) + ...
        a8*cos(8*x*w) + b8*sin(8*x*w);
y = f(x);
end