function voice = c2(pitch)
% crotchet
voice = note2(pitch, 1/4);
end