function voice = f(pitch)
% fullnote
voice = note(pitch, 1);
end
