function [pitch, blk] = pitch()

f0 = 2^(1/4)*261.6;

pitch = ones(12, 4);
ScaleTable1 = 2.^(1/12 .* [0: 1: 11]);
ScaleTable2 = 2.^(1/12 .* [12: 1: 23]);
ScaleTable3 = 2.^(1/12 .* [-12: 1: -1]);
ScaleTable4 = 2.^(1/12 .* [-24: 1: -13]);
pitch(:, 1) = 2*pi*f0.*ScaleTable1;
pitch(:, 2) = 2*pi*f0.*ScaleTable2;
pitch(:, 3) = 2*pi*f0.*ScaleTable3;
pitch(:, 4) = 2*pi*f0.*ScaleTable4;

blk = 0;

end