function voice = h(pitch)
% halfnote
voice = note(pitch, 1/2);
end
