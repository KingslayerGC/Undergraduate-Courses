function voice = note2(pitch, beat)

alpha = beat * 16;

fs = 44100;
dt = 1/fs;
T = 1/fs*4000;
t = [0:dt:T];
[~, k] = size(t);
t = linspace(0,alpha*T,alpha*k);


mod = normpdf(pi*t/t(end), 1.5, 0.5);
% mod = sin(pi*t/t(end));
voice = mod .* tone_test(pitch * t);
end

