function voice = h2(pitch)
% halfnote
voice = note2(pitch, 1/2);
end
