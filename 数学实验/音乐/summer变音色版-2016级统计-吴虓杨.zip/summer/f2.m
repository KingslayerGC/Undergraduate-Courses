function voice = f2(pitch)
% fullnote
voice = note2(pitch, 1);
end
