function voice = q2(pitch)
%  quaver
voice = note2(pitch, 1/8);
end