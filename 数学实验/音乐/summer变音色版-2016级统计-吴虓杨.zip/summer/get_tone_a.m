filename = 'Summer_sample.flac';
[voice, Fs] = audioread(filename);
y = voice(:,1);
z = y(1215:1566)*8.5;
n = length(z);

z = repmat(z, 3, 1);
x = -2*pi+ 4*pi/length(z): 6*pi/length(z): 4*pi;

z = z(352-10: 352+n+10);
x = x(352-10: 352+n+10);


plot(x, z)
