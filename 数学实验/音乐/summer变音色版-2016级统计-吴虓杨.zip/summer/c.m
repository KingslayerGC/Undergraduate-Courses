function voice = c(pitch)
% crotchet
voice = note(pitch, 1/4);
end