filename = 'Summer_sample.flac';
[voice, Fs] = audioread(filename);
y = voice(:,1);
z = y(1215:1566)*8.5;
n = length(z);
n = floor(n/3);

z = repmat(z, 3, 1);
x = -2*pi+ 4*pi/length(z): 6*pi/length(z): 4*pi;

z1 = z(352-20: 352+n+20);
z2 = z(352+n-20: 352+2*n+20);
z3 = z(352+2*n-20: 352+3*n+20);

x1 = x(352-20: 352+n+20);
x2 = x(352+n-20: 352+2*n+20);
x3 = x(352+2*n-20: 352+3*n+20);


plot(z2)
