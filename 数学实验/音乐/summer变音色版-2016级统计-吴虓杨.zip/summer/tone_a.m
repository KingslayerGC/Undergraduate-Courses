function Y = tone_a(X)

X = mod(X, 2*pi);
a0 =    -0.01464;
       a1 =     -0.2439;
       b1 =     -0.1485 ;
       a2 =     -0.1375 ;
       b2 =      0.1186;
       a3 =      0.1171;
       b3 =      0.2034;
       a4 =     0.01176;
       b4 =     -0.1107;
       a5 =     -0.1027;
       b5 =     0.04516;
       a6 =    -0.05239;
       b6 =     -0.1316;
       a7 =    -0.08155;
       b7 =    -0.05109;
       a8 =     -0.1331;
       b8 =     0.09184;
       w =      0.8746; 

f = @(x) a0 + a1*cos(x*w) + b1*sin(x*w) + ...
               a2*cos(2*x*w) + b2*sin(2*x*w) + a3*cos(3*x*w) + b3*sin(3*x*w) + ...
               a4*cos(4*x*w) + b4*sin(4*x*w) + a5*cos(5*x*w) + b5*sin(5*x*w) + ...
               a6*cos(6*x*w) + b6*sin(6*x*w) + a7*cos(7*x*w) + b7*sin(7*x*w) + ...
               a8*cos(8*x*w) + b8*sin(8*x*w);
Y = f(X);          
Y([end-1000:end,1:1000]) = conv(Y([end-1000:end,1:1000]), ones(1, 10)*1/10, 'same'); 
Y = conv(Y, ones(1, 50)*1/50, 'same');

end