function y = tone_test(x)
y = x;
x = mod(x, 2*pi);

y(x<2.1) = tone1(x(x<2.1));
y(x<4.14 & x >= 2.1) = tone2(x(x<4.14 & x >= 2.1));
y(x>=4.14) = tone3(x(x>=4.14));

y([end-100:end,1:100]) = conv(y([end-100:end,1:100]), ones(1, 10)*1/10, 'same'); 
y = conv(y, ones(1, 50)*1/50, 'same');

end